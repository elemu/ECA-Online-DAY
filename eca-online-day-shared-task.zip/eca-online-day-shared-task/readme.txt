README FILES:

timespan: 15/07/2020 --- 15/08/2020 

filter keyword: 'green pass'

Twitter dataset 

number of tweets: 33,686 

News dataset:

sources= The Sun, The Independent, The Guardian, BBC News

number of articles = 16 




MAP (Multimodal Analytic Platform) accounts:

user1 jelly22fi$h
user2 .Susan53
user3 $m3llycat
user4 &ebay.44
user5 SterlingGmail20.15
user6 !Lov3MyPiano
user7 BankLogin!3
user8 i7ovemydog!!
user9 Karm@beatsDogm@
user10 Dog.lov3r

http://35.246.69.64:8000 